package PGETEST.demo.dataobject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
	@Table(name="employee")
	public class EmployeeDO {
		@Id
		@Column(name="emp_id")
		private String empId;
		
		@Column(name="emp_fname")
	    private String empFirstName;
	    
		@Column(name="emp_lname")
	    private String empLastName;
	    
}		
