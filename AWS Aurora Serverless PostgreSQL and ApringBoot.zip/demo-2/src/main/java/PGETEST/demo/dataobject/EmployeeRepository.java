package PGETEST.demo.dataobject;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
	public interface EmployeeRepository extends CrudRepository<EmployeeDO,String> {
		
		 // @Query(value = "SELECT * FROM employee where emp_id=1", nativeQuery = true)
		  //EmployeeDO findByEmployeeIds(String original_title);
		
	}