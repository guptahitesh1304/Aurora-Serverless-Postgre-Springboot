package PGETEST.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import PGETEST.demo.dataobject.EmployeeDO;
import PGETEST.demo.dataobject.EmployeeRepository;

@RestController
@RequestMapping("/Demo/")
@EnableJpaRepositories("PGETEST.demo.dataobject")
@EntityScan( basePackages = {"PGETEST.demo"} )
public class DemoController {

	@Autowired
	EmployeeRepository employeeRepository;
	
	
	@GetMapping("/allEmployee")
	@ResponseBody
	public List<EmployeeDO> allEmployee() {
		return (List<EmployeeDO>) employeeRepository.findAll();
	}
	
	@PostMapping("/insertEmployee")
	public void insertNewEmployee(@RequestBody EmployeeDO employeeDO) {
		employeeRepository.save(employeeDO);
	}
	
	@GetMapping("/insertEmployeeTest")
	public void insertMovieTest() {
		EmployeeDO emp = new EmployeeDO();
		emp.setEmpId("25");
		emp.setEmpFirstName("J"); 
		emp.setEmpLastName("XXXX");
	
		employeeRepository.save(emp);
	}
}
